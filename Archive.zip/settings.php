<?php
$host = "localhost";
//database credentials, please create a database by going to your control panel -> MySQL Management -> Create new database, get the new database credentials and use them to replace the values below:
$username = "complet9_notes";
$password = "99999999";
$dbname = "complet9_notes";
//copy paste your project root directory below:
//for example, if your domain is student.host20.uk and you placed your notes app project called NotesApp inside your public_html folder, then your root directory would be: student.host20.uk/NotesApp/ 
//Please don't forget the forward slash "/" at the end.
$projectRoot = "your_domain/project_directory/";
?>